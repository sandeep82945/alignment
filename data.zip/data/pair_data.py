import json
from itertools import combinations
import pandas as pd
import yaml

class SFTTrainingDataset:
    def __init__(self, input_file):
        self.input_file = input_file
        self.data = self.load_json()
        self.doc_dict = self.group_by_doc_id()

    def load_json(self):
        with open(self.input_file, 'r') as file:
            return json.load(file)

    def group_by_doc_id(self):
        doc_dict = {}
        for entry in self.data:
            doc_id = entry['doc_id']
            if doc_id not in doc_dict:
                doc_dict[doc_id] = []
            doc_dict[doc_id].append(entry)
        return doc_dict

    @staticmethod
    def compare_scores(scores_a, scores_b):
        aspects = ['coherence', 'consistency', 'fluency', 'relevance', 'overall']
        results = {}
        for aspect in aspects:
            if scores_a[aspect] > scores_b[aspect]:
                results[aspect] = ' A is better than B [[A]]'
            elif scores_a[aspect] < scores_b[aspect]:
                results[aspect] = 'B is better than A [[B]]'
            else:
                results[aspect] = 'Its a tie between A and B [[C]]'
        return results

    def generate_training_data(self):
        training_data = []
        for doc_id, outputs in self.doc_dict.items():
            pairs = combinations(outputs, 2)
            for a, b in pairs:
                comparison = self.compare_scores(a['scores'], b['scores'])
                training_data.append({
                    'doc_id': doc_id,
                    'source': a['source'],
                    'reference': a['reference'],
                    'system_id_a': a['system_id'],
                    'system_output_a': a['system_output'],
                    'scores_a': a['scores'],
                    'system_id_b': b['system_id'],
                    'system_output_b': b['system_output'],
                    'scores_b': b['scores'],
                    'comparison': comparison
                })
        return training_data

    def save_to_json(self, data, output_file):
        df = pd.DataFrame(data)
        pd.set_option('display.max_colwidth', None)  # Ensure the full content of each column is displayed
        print(df.head())
        df.to_json(output_file, orient='records', lines=True)

    def create_dataset(self, output_file=None, return_json=False):
        training_data = self.generate_training_data()
        if output_file:
            self.save_to_json(training_data, output_file)
        
        if return_json:
            return training_data

class InputOutputPairs:
    def __init__(self, config):
        self.prompt_coh = open(config["Prompt_dir"]["coh"]).read()
        self.prompt_con = open(config["Prompt_dir"]["con"]).read()
        self.prompt_flu = open(config["Prompt_dir"]["flu"]).read()
        self.prompt_rel = open(config["Prompt_dir"]["rel"]).read()

    def create_input_output_pairs(self, training_data):
        input_output_pairs = []
        for entry in training_data:
            for aspect, prompt in zip(
                ['coherence', 'consistency', 'fluency', 'relevance'],
                [self.prompt_coh, self.prompt_con, self.prompt_flu, self.prompt_rel]
            ):
                input_output_pairs.append({
                    'input': f"{prompt}\nSource: {entry['source']}\nReference: {entry['reference']}\nSystem A: {entry['system_output_a']}\nSystem B: {entry['system_output_b']}",
                    'output': json.dumps({aspect: entry['comparison'][aspect]})
                })
        return input_output_pairs

    @staticmethod
    def save_input_output_pairs_to_json(input_output_pairs, output_file):
        with open(output_file, 'w') as file:
            for pair in input_output_pairs:
                file.write(json.dumps(pair) + '\n')

# Load configuration
with open('../config.yaml', 'r') as file:
    config = yaml.safe_load(file)

# Example usage
input_file = 'train_data.json'
output_file = 'training_data_with_scores.json'
pair_output_file = 'input_output_pairs.json'

sft_dataset = SFTTrainingDataset(input_file)
training_data = sft_dataset.create_dataset(output_file=output_file, return_json=True)

io_pairs = InputOutputPairs(config)
input_output_pairs = io_pairs.create_input_output_pairs(training_data)

if pair_output_file:
    InputOutputPairs.save_input_output_pairs_to_json(input_output_pairs, pair_output_file)

result_json = {
    'training_data': training_data,
    'input_output_pairs': input_output_pairs
}

print(result_json)

